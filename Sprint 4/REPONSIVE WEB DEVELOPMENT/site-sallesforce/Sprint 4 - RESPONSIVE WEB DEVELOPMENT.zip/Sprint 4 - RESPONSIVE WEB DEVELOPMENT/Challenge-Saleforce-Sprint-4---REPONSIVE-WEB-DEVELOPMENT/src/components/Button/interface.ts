export interface Props {
    text: string;
    link: string;
    style: string;
    type?: string;
};